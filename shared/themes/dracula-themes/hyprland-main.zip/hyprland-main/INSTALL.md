### [Hyprland](https://hyprland.org)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    git clone https://github.com/dracula/hyprland.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/hyprland/archive/master.zip) option and unzip them.

#### Activating theme

Copy/replace the given colors from `hyprland.conf` into `~/.config/hypr/hyprland.conf`.

ie. `cat hyprland.conf >> ~/.config/hypr/hyprland.conf` and adjust with your preferred editor.

