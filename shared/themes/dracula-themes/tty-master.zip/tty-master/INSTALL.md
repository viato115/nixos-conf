### TTY

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    git clone https://github.com/dracula/tty.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/tty/archive/master.zip) option and unzip them.

#### Activating theme

1. Copy the contents of `dracula-tty.sh` into `~/.bashrc` (if you use bash, or
   `~/.zshrc` for zsh, etc)
2. Boom! It's working
